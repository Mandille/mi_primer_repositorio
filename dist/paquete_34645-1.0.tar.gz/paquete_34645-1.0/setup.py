from setuptools import setup #importo una funcion del paquete setuptools

setup(
    name="paquete_34645",
    version=1.0,
    description="Paquete de la comision 34645",
    author="La comi 34645",
    packages=["paquete"],
)

